from .models import Notification


def user_notification_count(request):
    if not request.user.is_authenticated or getattr(request.user, "role", None) != "user":
        return {}

    count = Notification.objects.filter(user=request.user, is_read=False).count()
    return {"user_unread_notification_count": count}
