from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404, redirect, render

from .models import Notification
from .services import NotificationService
from dashboard.utils import paginate_queryset, pagination_querystring


@login_required
def notification_list(request):
    notifications = Notification.objects.filter(user=request.user)
    page_obj = paginate_queryset(request, notifications, 10)
    return render(
        request,
        "user/notifications.html",
        {"notifications": page_obj, "page_obj": page_obj, "pagination_query": pagination_querystring(request)},
    )


@login_required
def mark_read(request, notification_id):
    notification = get_object_or_404(Notification, pk=notification_id, user=request.user)
    notification.mark_as_read()
    messages.success(request, "Notifikasi ditandai sudah dibaca.")
    return redirect("notification_list")


@login_required
def mark_all_read(request):
    NotificationService.mark_all_as_read(request.user)
    messages.success(request, "Semua notifikasi ditandai sudah dibaca.")
    return redirect("notification_list")

# Create your views here.
