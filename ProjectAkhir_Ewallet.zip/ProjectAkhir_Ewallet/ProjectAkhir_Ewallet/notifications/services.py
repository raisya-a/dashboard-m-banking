from .models import Notification


class NotificationService:
    @staticmethod
    def create_notification(user, title, message):
        return Notification.objects.create(user=user, title=title, message=message)

    @staticmethod
    def unread_count(user):
        return Notification.objects.filter(user=user, is_read=False).count()

    @staticmethod
    def mark_all_as_read(user):
        Notification.objects.filter(user=user, is_read=False).update(is_read=True)
