from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db.models import Count, Q
from django.shortcuts import get_object_or_404, redirect, render

from accounts.decorators import admin_required
from accounts.forms import BlockUserForm, ManagedAdminForm, ManagedUserForm
from accounts.models import LoginActivity, User
from reports.models import Report
from wallet.models import TopUp, Transaction
from wallet.services import TopUpService

from .services import BlockUserService
from .utils import paginate_queryset, pagination_querystring


@login_required
@admin_required
def admin_dashboard(request):
    context = {
        "total_user": User.objects.filter(role=User.ROLE_USER).count(),
        "total_user_active": User.objects.filter(role=User.ROLE_USER, status=User.STATUS_ACTIVE).count(),
        "total_user_blocked": User.objects.filter(role=User.ROLE_USER, status=User.STATUS_BLOCKED).count(),
        "total_transaction": Transaction.objects.count(),
        "total_topup_pending": TopUp.objects.filter(status=TopUp.STATUS_PENDING).count(),
        "total_report": Report.objects.count(),
    }
    return render(request, "admin_panel/dashboard.html", context)


@login_required
@admin_required
def admin_users(request):
    users = User.objects.filter(role=User.ROLE_USER).annotate(
        transaction_count=Count("transactions"),
        report_count=Count("reports"),
    ).order_by("full_name", "id")
    keyword = request.GET.get("q", "")
    if keyword:
        users = users.filter(Q(username__icontains=keyword) | Q(full_name__icontains=keyword) | Q(email__icontains=keyword))
    page_obj = paginate_queryset(request, users, 10)
    return render(
        request,
        "admin_panel/users.html",
        {"users": page_obj, "page_obj": page_obj, "pagination_query": pagination_querystring(request), "keyword": keyword},
    )


@login_required
@admin_required
def admin_user_detail(request, user_id):
    user_obj = get_object_or_404(User, pk=user_id, role=User.ROLE_USER)
    transactions = Transaction.objects.filter(user=user_obj)[:10]
    activities = LoginActivity.objects.filter(user=user_obj)[:10]
    reports = Report.objects.filter(user=user_obj)[:10]
    form = BlockUserForm()
    return render(
        request,
        "admin_panel/user_detail.html",
        {"user_obj": user_obj, "transactions": transactions, "activities": activities, "reports": reports, "form": form},
    )


@login_required
@admin_required
def admin_user_create(request):
    form = ManagedUserForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        user_obj = form.save()
        messages.success(request, "Akun berhasil dibuat.")
        return redirect("admin_user_detail", user_id=user_obj.id)
    return render(request, "admin_panel/user_form.html", {"form": form, "title": "Tambah User", "submit_label": "Simpan User"})


@login_required
@admin_required
def admin_user_edit(request, user_id):
    user_obj = get_object_or_404(User, pk=user_id, role=User.ROLE_USER)
    form = ManagedUserForm(request.POST or None, instance=user_obj)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Akun berhasil diperbarui.")
        return redirect("admin_user_detail", user_id=user_obj.id)
    return render(
        request,
        "admin_panel/user_form.html",
        {"form": form, "title": "Edit User", "submit_label": "Simpan Perubahan", "user_obj": user_obj},
    )


@login_required
@admin_required
def admin_user_delete(request, user_id):
    user_obj = get_object_or_404(User, pk=user_id, role=User.ROLE_USER)

    if request.method == "POST":
        user_obj.delete()
        messages.success(request, "Akun berhasil dihapus.")
        return redirect("admin_users")

    return render(request, "admin_panel/user_confirm_delete.html", {"user_obj": user_obj})


@login_required
@admin_required
def admin_admins(request):
    admins = User.objects.filter(role=User.ROLE_ADMIN).order_by("full_name", "id")
    keyword = request.GET.get("q", "")
    if keyword:
        admins = admins.filter(Q(username__icontains=keyword) | Q(full_name__icontains=keyword) | Q(email__icontains=keyword))
    page_obj = paginate_queryset(request, admins, 10)
    return render(
        request,
        "admin_panel/admins.html",
        {"admins": page_obj, "page_obj": page_obj, "pagination_query": pagination_querystring(request), "keyword": keyword},
    )


@login_required
@admin_required
def admin_admin_detail(request, admin_id):
    admin_obj = get_object_or_404(User, pk=admin_id, role=User.ROLE_ADMIN)
    activities = LoginActivity.objects.filter(user=admin_obj)[:10]
    return render(request, "admin_panel/admin_detail.html", {"admin_obj": admin_obj, "activities": activities})


@login_required
@admin_required
def admin_admin_create(request):
    form = ManagedAdminForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        admin_obj = form.save()
        messages.success(request, "Admin berhasil dibuat.")
        return redirect("admin_admin_detail", admin_id=admin_obj.id)
    return render(request, "admin_panel/admin_form.html", {"form": form, "title": "Tambah Admin", "submit_label": "Simpan Admin"})


@login_required
@admin_required
def admin_admin_edit(request, admin_id):
    admin_obj = get_object_or_404(User, pk=admin_id, role=User.ROLE_ADMIN)
    form = ManagedAdminForm(request.POST or None, instance=admin_obj)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Admin berhasil diperbarui.")
        return redirect("admin_admin_detail", admin_id=admin_obj.id)
    return render(
        request,
        "admin_panel/admin_form.html",
        {"form": form, "title": "Edit Admin", "submit_label": "Simpan Perubahan", "admin_obj": admin_obj},
    )


@login_required
@admin_required
def admin_admin_delete(request, admin_id):
    admin_obj = get_object_or_404(User, pk=admin_id, role=User.ROLE_ADMIN)
    if admin_obj.pk == request.user.pk:
        messages.error(request, "Anda tidak bisa menghapus akun admin sendiri.")
        return redirect("admin_admin_detail", admin_id=admin_obj.id)

    if request.method == "POST":
        admin_obj.delete()
        messages.success(request, "Admin berhasil dihapus.")
        return redirect("admin_admins")

    return render(request, "admin_panel/admin_confirm_delete.html", {"admin_obj": admin_obj})


@login_required
@admin_required
def block_user(request, user_id):
    user_obj = get_object_or_404(User, pk=user_id, role=User.ROLE_USER)
    form = BlockUserForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        BlockUserService.block_user(user_obj, form.cleaned_data["reason"])
        messages.success(request, "User berhasil diblokir.")
    else:
        messages.error(request, "Alasan pemblokiran wajib diisi minimal 10 karakter.")
    return redirect("admin_user_detail", user_id=user_obj.id)


@login_required
@admin_required
def unblock_user(request, user_id):
    user_obj = get_object_or_404(User, pk=user_id, role=User.ROLE_USER)
    BlockUserService.unblock_user(user_obj)
    messages.success(request, "Blokir user berhasil dibuka.")
    return redirect("admin_user_detail", user_id=user_obj.id)


@login_required
@admin_required
def login_activities(request):
    activities = LoginActivity.objects.select_related("user").all()
    page_obj = paginate_queryset(request, activities, 10)
    return render(
        request,
        "admin_panel/login_activities.html",
        {"activities": page_obj, "page_obj": page_obj, "pagination_query": pagination_querystring(request)},
    )


@login_required
@admin_required
def admin_transactions(request):
    transactions = Transaction.objects.select_related("user", "target_user").all()
    transaction_type = request.GET.get("type", "")
    status = request.GET.get("status", "")
    keyword = request.GET.get("q", "")
    if transaction_type:
        transactions = transactions.filter(transaction_type=transaction_type)
    if status:
        transactions = transactions.filter(status=status)
    if keyword:
        transactions = transactions.filter(Q(user__full_name__icontains=keyword) | Q(user__username__icontains=keyword))
    page_obj = paginate_queryset(request, transactions, 10)
    return render(
        request,
        "admin_panel/transactions.html",
        {
            "transactions": page_obj,
            "page_obj": page_obj,
            "pagination_query": pagination_querystring(request),
            "transaction_type": transaction_type,
            "status": status,
            "keyword": keyword,
            "type_choices": Transaction.TYPE_CHOICES,
            "status_choices": Transaction.STATUS_CHOICES,
        },
    )


@login_required
@admin_required
def topup_pending(request):
    topups = TopUp.objects.select_related("user").filter(status=TopUp.STATUS_PENDING)
    page_obj = paginate_queryset(request, topups, 10)
    return render(
        request,
        "admin_panel/topup_pending.html",
        {"topups": page_obj, "page_obj": page_obj, "pagination_query": pagination_querystring(request)},
    )


@login_required
@admin_required
def approve_topup(request, topup_id):
    topup = get_object_or_404(TopUp, pk=topup_id)
    try:
        TopUpService.approve_topup(topup)
        messages.success(request, "Top up berhasil disetujui.")
    except ValueError as exc:
        messages.error(request, str(exc))
    return redirect("topup_pending")


@login_required
@admin_required
def reject_topup(request, topup_id):
    topup = get_object_or_404(TopUp, pk=topup_id)
    TopUpService.reject_topup(topup)
    messages.success(request, "Top up berhasil ditolak.")
    return redirect("topup_pending")

# Create your views here.
