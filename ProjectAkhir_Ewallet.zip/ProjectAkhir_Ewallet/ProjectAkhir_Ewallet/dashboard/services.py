from django.utils import timezone

from accounts.models import User
from notifications.services import NotificationService


class BlockUserService:
    @staticmethod
    def block_user(user, reason):
        user.status = User.STATUS_BLOCKED
        user.blocked_reason = reason
        user.blocked_at = timezone.now()
        user.save(update_fields=["status", "blocked_reason", "blocked_at"])
        NotificationService.create_notification(
            user,
            "Akun Diblokir",
            f"Akun Anda diblokir admin. Alasan: {reason}",
        )
        return user

    @staticmethod
    def unblock_user(user):
        user.status = User.STATUS_ACTIVE
        user.blocked_reason = ""
        user.blocked_at = None
        user.save(update_fields=["status", "blocked_reason", "blocked_at"])
        NotificationService.create_notification(
            user,
            "Akun Dibuka Blokir",
            "Akun Anda sudah aktif kembali dan dapat melakukan transaksi.",
        )
        return user
