from django.test import TestCase
from django.urls import reverse

from accounts.models import User
from accounts.services import AuthService


class AdminUserCrudTests(TestCase):
    def setUp(self):
        self.admin = AuthService.create_user(
            username="admin",
            email="admin@gmail.com",
            full_name="Administrator",
            phone="080000000000",
            password="admin123",
            pin="123456",
            role=User.ROLE_ADMIN,
        )

    def test_admin_can_create_admin_account(self):
        self.client.login(username="admin", password="admin123")

        response = self.client.post(
            reverse("admin_admin_create"),
            {
                "full_name": "Admin Baru",
                "phone": "089999999999",
                "email": "adminbaru@gmail.com",
                "username": "adminbaru",
                "password": "adminbaru123",
                "confirm_password": "adminbaru123",
            },
        )

        created = User.objects.get(username="adminbaru")
        self.assertRedirects(response, reverse("admin_admin_detail", args=[created.id]))
        self.assertEqual(created.role, User.ROLE_ADMIN)
        self.assertTrue(created.is_staff)
        self.assertEqual(created.balance, 0)

    def test_admin_cannot_delete_own_account(self):
        self.client.login(username="admin", password="admin123")

        response = self.client.post(reverse("admin_admin_delete", args=[self.admin.id]))

        self.assertRedirects(response, reverse("admin_admin_detail", args=[self.admin.id]))
        self.assertTrue(User.objects.filter(pk=self.admin.pk).exists())

    def test_admin_create_rejects_password_confirmation_mismatch(self):
        self.client.login(username="admin", password="admin123")

        response = self.client.post(
            reverse("admin_admin_create"),
            {
                "full_name": "Admin Salah",
                "phone": "087777777777",
                "email": "adminsalah@gmail.com",
                "username": "adminsalah",
                "password": "admin12345",
                "confirm_password": "beda12345",
            },
        )

        self.assertEqual(response.status_code, 200)
        self.assertFalse(User.objects.filter(username="adminsalah").exists())

# Create your tests here.
