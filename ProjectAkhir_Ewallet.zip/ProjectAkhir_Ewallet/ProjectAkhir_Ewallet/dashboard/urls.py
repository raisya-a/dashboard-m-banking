from django.urls import path

from . import views

urlpatterns = [
    path("admin/", views.admin_dashboard, name="admin_dashboard"),
    path("admin/users/", views.admin_users, name="admin_users"),
    path("admin/users/create/", views.admin_user_create, name="admin_user_create"),
    path("admin/users/<int:user_id>/", views.admin_user_detail, name="admin_user_detail"),
    path("admin/users/<int:user_id>/edit/", views.admin_user_edit, name="admin_user_edit"),
    path("admin/users/<int:user_id>/delete/", views.admin_user_delete, name="admin_user_delete"),
    path("admin/users/<int:user_id>/block/", views.block_user, name="block_user"),
    path("admin/users/<int:user_id>/unblock/", views.unblock_user, name="unblock_user"),
    path("admin/admins/", views.admin_admins, name="admin_admins"),
    path("admin/admins/create/", views.admin_admin_create, name="admin_admin_create"),
    path("admin/admins/<int:admin_id>/", views.admin_admin_detail, name="admin_admin_detail"),
    path("admin/admins/<int:admin_id>/edit/", views.admin_admin_edit, name="admin_admin_edit"),
    path("admin/admins/<int:admin_id>/delete/", views.admin_admin_delete, name="admin_admin_delete"),
    path("admin/login-activities/", views.login_activities, name="login_activities"),
    path("admin/transactions/", views.admin_transactions, name="admin_transactions"),
    path("admin/topup-pending/", views.topup_pending, name="topup_pending"),
    path("admin/topup-pending/<int:topup_id>/approve/", views.approve_topup, name="approve_topup"),
    path("admin/topup-pending/<int:topup_id>/reject/", views.reject_topup, name="reject_topup"),
]
