from django.contrib.auth.models import AbstractUser
from django.db import models
from django.utils import timezone


class User(AbstractUser):
    ROLE_ADMIN = "admin"
    ROLE_USER = "user"
    STATUS_ACTIVE = "active"
    STATUS_BLOCKED = "blocked"

    ROLE_CHOICES = (
        (ROLE_ADMIN, "Admin"),
        (ROLE_USER, "User"),
    )
    STATUS_CHOICES = (
        (STATUS_ACTIVE, "Aktif"),
        (STATUS_BLOCKED, "Diblokir"),
    )

    full_name = models.CharField("nama lengkap", max_length=150)
    phone = models.CharField("nomor HP", max_length=20)
    email = models.EmailField("email", unique=True)
    pin = models.CharField("PIN", max_length=255)
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default=ROLE_USER)
    balance = models.DecimalField("saldo", max_digits=12, decimal_places=2, default=0)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=STATUS_ACTIVE)
    blocked_reason = models.TextField("alasan blokir", null=True, blank=True)
    blocked_at = models.DateTimeField("waktu blokir", null=True, blank=True)
    created_at = models.DateTimeField("waktu dibuat", auto_now_add=True)
    REQUIRED_FIELDS = ["email", "full_name", "phone"]

    def is_admin_user(self):
        return self.role == self.ROLE_ADMIN

    def is_normal_user(self):
        return self.role == self.ROLE_USER

    def is_blocked(self):
        return self.status == self.STATUS_BLOCKED

    def block(self, reason):
        self.status = self.STATUS_BLOCKED
        self.blocked_reason = reason
        self.blocked_at = timezone.now()

    def unblock(self):
        self.status = self.STATUS_ACTIVE
        self.blocked_reason = ""
        self.blocked_at = None

    def __str__(self):
        return self.full_name or self.username


class LoginActivity(models.Model):
    ACTIVITY_LOGIN = "login"
    ACTIVITY_LOGOUT = "logout"
    ACTIVITY_CHOICES = (
        (ACTIVITY_LOGIN, "Login"),
        (ACTIVITY_LOGOUT, "Logout"),
    )

    user = models.ForeignKey(User, on_delete=models.CASCADE)
    activity_type = models.CharField(max_length=20, choices=ACTIVITY_CHOICES)
    activity_time = models.DateTimeField(auto_now_add=True)
    ip_address = models.CharField(max_length=100, blank=True, null=True)
    user_agent = models.TextField(blank=True, null=True)

    class Meta:
        ordering = ["-activity_time"]
        verbose_name_plural = "login activities"

    def __str__(self):
        return f"{self.user.full_name} - {self.activity_type}"

# Create your models here.
