from django.core.management.base import BaseCommand

from accounts.models import User
from accounts.services import AuthService


class Command(BaseCommand):
    help = "Membuat akun admin dan user demo."

    def handle(self, *args, **options):
        if not User.objects.filter(username="admin").exists():
            AuthService.create_user(
                username="admin",
                email="admin@gmail.com",
                full_name="Administrator",
                phone="080000000000",
                password="admin123",
                pin="123456",
                role=User.ROLE_ADMIN,
            )
            self.stdout.write(self.style.SUCCESS("Admin demo dibuat."))
        else:
            self.stdout.write("Admin demo sudah ada.")

        if not User.objects.filter(username="user").exists():
            AuthService.create_user(
                username="user",
                email="user@gmail.com",
                full_name="User Demo",
                phone="081234567890",
                password="user123",
                pin="123456",
                role=User.ROLE_USER,
                balance=100000,
            )
            self.stdout.write(self.style.SUCCESS("User demo dibuat."))
        else:
            self.stdout.write("User demo sudah ada.")
