from django.contrib import messages
from django.shortcuts import redirect, render

from .forms import LoginForm, RegisterForm
from .services import AuthService


def login_view(request):
    if request.user.is_authenticated:
        if request.user.role == "admin":
            return redirect("admin_dashboard")
        return redirect("user_dashboard")

    form = LoginForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        user = AuthService.authenticate_user(
            request,
            form.cleaned_data["username"],
            form.cleaned_data["password"],
        )
        if user:
            AuthService.login_user(request, user)
            messages.success(request, "Login berhasil. Selamat datang.")
            if user.role == "admin":
                return redirect("admin_dashboard")
            return redirect("user_dashboard")
        messages.error(request, "Username/email atau password salah.")

    return render(request, "auth/login.html", {"form": form})


def register_view(request):
    if request.user.is_authenticated:
        return redirect("user_dashboard")

    form = RegisterForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        AuthService.register_user(form)
        messages.success(request, "Pendaftaran berhasil. Silakan login.")
        return redirect("login")

    return render(request, "auth/register.html", {"form": form})


def logout_view(request):
    AuthService.logout_user(request)
    messages.success(request, "Logout berhasil.")
    return redirect("login")

# Create your views here.
