from django import forms
from django.contrib.auth.hashers import make_password
from django.utils import timezone

from .models import User


class RegisterForm(forms.ModelForm):
    password = forms.CharField(label="Password", widget=forms.PasswordInput)
    confirm_password = forms.CharField(label="Konfirmasi Password", widget=forms.PasswordInput)
    pin = forms.CharField(label="PIN Transaksi", min_length=6, max_length=6, widget=forms.PasswordInput)

    class Meta:
        model = User
        fields = ["full_name", "phone", "email", "username", "password", "confirm_password", "pin"]
        labels = {
            "full_name": "Nama Lengkap",
            "phone": "Nomor HP",
            "email": "Email",
            "username": "Username",
        }

    def clean(self):
        cleaned_data = super().clean()
        password = cleaned_data.get("password")
        confirm_password = cleaned_data.get("confirm_password")

        if password and confirm_password and password != confirm_password:
            raise forms.ValidationError("Password dan konfirmasi password tidak sama.")

        return cleaned_data

    def clean_pin(self):
        pin = self.cleaned_data["pin"]
        if not pin.isdigit():
            raise forms.ValidationError("PIN harus berupa 6 angka.")
        return pin

    def save(self, commit=True):
        user = super().save(commit=False)
        user.password = make_password(self.cleaned_data["password"])
        user.pin = make_password(self.cleaned_data["pin"])
        user.role = User.ROLE_USER
        user.status = User.STATUS_ACTIVE
        user.balance = 0
        if commit:
            user.save()
        return user


class LoginForm(forms.Form):
    username = forms.CharField(label="Username atau Email")
    password = forms.CharField(label="Password", widget=forms.PasswordInput)


class BlockUserForm(forms.Form):
    reason = forms.CharField(label="Alasan Pemblokiran", widget=forms.Textarea, min_length=10)


class ManagedUserForm(forms.ModelForm):
    password = forms.CharField(label="Password", widget=forms.PasswordInput, required=False)
    confirm_password = forms.CharField(label="Konfirmasi Password", widget=forms.PasswordInput, required=False)
    pin = forms.CharField(label="PIN Transaksi", min_length=6, max_length=6, widget=forms.PasswordInput, required=False)

    class Meta:
        model = User
        fields = [
            "full_name",
            "phone",
            "email",
            "username",
            "password",
            "confirm_password",
            "pin",
            "balance",
            "status",
            "blocked_reason",
        ]
        labels = {
            "full_name": "Nama Lengkap",
            "phone": "Nomor HP",
            "email": "Email",
            "username": "Username",
            "balance": "Saldo",
            "status": "Status",
            "blocked_reason": "Alasan Blokir",
        }

    def __init__(self, *args, current_user=None, **kwargs):
        super().__init__(*args, **kwargs)
        if not self.instance.pk:
            self.fields["password"].required = True
            self.fields["confirm_password"].required = True
            self.fields["pin"].required = True
            self.fields["password"].help_text = ""
            self.fields["confirm_password"].help_text = ""
            self.fields["pin"].help_text = ""
        else:
            self.fields["password"].help_text = "Kosongkan jika tidak ingin mengubah password."
            self.fields["confirm_password"].help_text = "Isi hanya jika password baru diisi."
            self.fields["pin"].help_text = "Kosongkan jika tidak ingin mengubah PIN."

    def clean_pin(self):
        pin = self.cleaned_data.get("pin")
        if pin and not pin.isdigit():
            raise forms.ValidationError("PIN harus berupa 6 angka.")
        return pin

    def clean(self):
        cleaned_data = super().clean()
        status = cleaned_data.get("status")
        blocked_reason = cleaned_data.get("blocked_reason")
        password = cleaned_data.get("password")
        confirm_password = cleaned_data.get("confirm_password")
        pin = cleaned_data.get("pin")

        if password or confirm_password:
            if password != confirm_password:
                raise forms.ValidationError("Password dan konfirmasi password tidak sama.")

        if not self.instance.pk and not pin:
            raise forms.ValidationError("PIN wajib diisi untuk akun User.")

        if self.instance.pk and not self.instance.pin and not pin:
            raise forms.ValidationError("PIN wajib diisi untuk akun User.")

        if status == User.STATUS_BLOCKED and not blocked_reason:
            raise forms.ValidationError("Alasan blokir wajib diisi jika status akun diblokir.")

        return cleaned_data

    def save(self, commit=True):
        user = super().save(commit=False)
        password = self.cleaned_data.get("password")
        pin = self.cleaned_data.get("pin")

        if password:
            user.password = make_password(password)
        if pin:
            user.pin = make_password(pin)

        user.role = User.ROLE_USER
        user.is_staff = False
        if user.status == User.STATUS_BLOCKED and not user.blocked_at:
            user.blocked_at = timezone.now()
        elif user.status == User.STATUS_ACTIVE:
            user.blocked_reason = ""
            user.blocked_at = None

        if commit:
            user.save()
        return user


class ManagedAdminForm(forms.ModelForm):
    password = forms.CharField(label="Password", widget=forms.PasswordInput, required=False)
    confirm_password = forms.CharField(label="Konfirmasi Password", widget=forms.PasswordInput, required=False)

    class Meta:
        model = User
        fields = ["full_name", "phone", "email", "username", "password", "confirm_password"]
        labels = {
            "full_name": "Nama Lengkap",
            "phone": "Nomor HP",
            "email": "Email",
            "username": "Username",
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if not self.instance.pk:
            self.fields["password"].required = True
            self.fields["confirm_password"].required = True
            self.fields["password"].help_text = ""
            self.fields["confirm_password"].help_text = ""
        else:
            self.fields["password"].help_text = "Kosongkan jika tidak ingin mengubah password."
            self.fields["confirm_password"].help_text = "Isi hanya jika password baru diisi."

    def clean(self):
        cleaned_data = super().clean()
        password = cleaned_data.get("password")
        confirm_password = cleaned_data.get("confirm_password")

        if password or confirm_password:
            if password != confirm_password:
                raise forms.ValidationError("Password dan konfirmasi password tidak sama.")

        return cleaned_data

    def save(self, commit=True):
        admin = super().save(commit=False)
        password = self.cleaned_data.get("password")
        if password:
            admin.password = make_password(password)

        admin.role = User.ROLE_ADMIN
        admin.balance = 0
        admin.status = User.STATUS_ACTIVE
        admin.blocked_reason = ""
        admin.blocked_at = None
        admin.pin = ""
        admin.is_staff = True

        if commit:
            admin.save()
        return admin
