from django.test import TestCase
from django.urls import reverse

from accounts.models import LoginActivity, User
from accounts.services import AuthService


class AuthFlowTests(TestCase):
    def setUp(self):
        self.user = AuthService.create_user(
            username="user",
            email="user@gmail.com",
            full_name="User Demo",
            phone="081234567890",
            password="user123",
            pin="123456",
            balance=100000,
        )
        self.admin = AuthService.create_user(
            username="admin",
            email="admin@gmail.com",
            full_name="Administrator",
            phone="080000000000",
            password="admin123",
            pin="123456",
            role=User.ROLE_ADMIN,
        )

    def test_user_login_records_activity_and_redirects(self):
        response = self.client.post(reverse("login"), {"username": "user", "password": "user123"})

        self.assertRedirects(response, reverse("user_dashboard"))
        self.assertEqual(LoginActivity.objects.filter(user=self.user, activity_type="login").count(), 1)

    def test_admin_login_redirects_to_admin_dashboard(self):
        response = self.client.post(reverse("login"), {"username": "admin", "password": "admin123"})

        self.assertRedirects(response, reverse("admin_dashboard"))

    def test_register_creates_normal_user(self):
        response = self.client.post(
            reverse("register"),
            {
                "full_name": "Budi Santoso",
                "phone": "081111111111",
                "email": "budi@gmail.com",
                "username": "budi",
                "password": "budi12345",
                "confirm_password": "budi12345",
                "pin": "654321",
            },
        )

        self.assertRedirects(response, reverse("login"))
        self.assertTrue(User.objects.filter(username="budi", role=User.ROLE_USER).exists())

    def test_blocked_user_wallet_pages_redirect_to_report_without_error(self):
        self.user.status = User.STATUS_BLOCKED
        self.user.blocked_reason = "Akun sedang ditinjau."
        self.user.save(update_fields=["status", "blocked_reason"])
        self.client.login(username="user", password="user123")

        transfer_response = self.client.get(reverse("transfer"))
        topup_response = self.client.get(reverse("topup"))

        self.assertRedirects(transfer_response, reverse("report_list"))
        self.assertRedirects(topup_response, reverse("report_list"))

# Create your tests here.
