from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.hashers import make_password

from .models import LoginActivity, User


class AuthService:
    @staticmethod
    def register_user(form):
        return form.save()

    @staticmethod
    def create_user(username, email, full_name, phone, password, pin, role=User.ROLE_USER, balance=0):
        return User.objects.create(
            username=username,
            email=email,
            full_name=full_name,
            phone=phone,
            password=make_password(password),
            pin=make_password(pin),
            role=role,
            balance=balance,
            status=User.STATUS_ACTIVE,
            is_staff=role == User.ROLE_ADMIN,
        )

    @staticmethod
    def authenticate_user(request, username_or_email, password):
        username = username_or_email
        if "@" in username_or_email:
            try:
                username = User.objects.get(email=username_or_email).username
            except User.DoesNotExist:
                return None
        return authenticate(request, username=username, password=password)

    @staticmethod
    def login_user(request, user):
        login(request, user)
        AuthService.record_activity(request, user, LoginActivity.ACTIVITY_LOGIN)

    @staticmethod
    def logout_user(request):
        if request.user.is_authenticated:
            AuthService.record_activity(request, request.user, LoginActivity.ACTIVITY_LOGOUT)
        logout(request)

    @staticmethod
    def record_activity(request, user, activity_type):
        LoginActivity.objects.create(
            user=user,
            activity_type=activity_type,
            ip_address=AuthService.get_client_ip(request),
            user_agent=request.META.get("HTTP_USER_AGENT", ""),
        )

    @staticmethod
    def get_client_ip(request):
        forwarded_for = request.META.get("HTTP_X_FORWARDED_FOR")
        if forwarded_for:
            return forwarded_for.split(",")[0]
        return request.META.get("REMOTE_ADDR", "")
