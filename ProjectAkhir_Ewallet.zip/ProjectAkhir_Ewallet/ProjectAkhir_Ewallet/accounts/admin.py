from django.contrib import admin
from django.contrib.auth.admin import UserAdmin

from .models import LoginActivity, User


@admin.register(User)
class CustomUserAdmin(UserAdmin):
    fieldsets = UserAdmin.fieldsets + (
        ("Data Wallet", {"fields": ("full_name", "phone", "pin", "role", "balance", "status", "blocked_reason", "blocked_at")}),
    )
    list_display = ("username", "full_name", "email", "role", "balance", "status")
    list_filter = ("role", "status")


@admin.register(LoginActivity)
class LoginActivityAdmin(admin.ModelAdmin):
    list_display = ("user", "activity_type", "activity_time", "ip_address")
    list_filter = ("activity_type",)

# Register your models here.
