from django.contrib import messages
from django.shortcuts import redirect


class BlockedUserMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        restricted_paths = ["/user/transfer/", "/user/topup/"]
        user = getattr(request, "user", None)

        if user and user.is_authenticated and user.role == "user" and user.status == "blocked":
            if any(request.path.startswith(path) for path in restricted_paths):
                messages.error(
                    request,
                    "Akun Anda sedang diblokir. Silakan ajukan pembukaan blokir melalui report.",
                )
                return redirect("report_list")

        return self.get_response(request)
