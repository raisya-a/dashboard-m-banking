from decimal import Decimal, InvalidOperation

from django import template

register = template.Library()


@register.filter
def rupiah(value):
    try:
        amount = Decimal(value)
    except (InvalidOperation, TypeError, ValueError):
        amount = Decimal("0")

    rounded = amount.quantize(Decimal("1"))
    formatted = f"{rounded:,.0f}".replace(",", ".")
    return f"Rp {formatted}"
