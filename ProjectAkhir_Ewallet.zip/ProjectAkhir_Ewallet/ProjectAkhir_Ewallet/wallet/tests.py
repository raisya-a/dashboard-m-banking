from django.test import TestCase
from django.urls import reverse

from accounts.models import User
from accounts.services import AuthService
from notifications.models import Notification
from wallet.models import TopUp, Transaction
from wallet.services import TopUpService, TransferService


class WalletServiceTests(TestCase):
    def setUp(self):
        self.sender = AuthService.create_user(
            username="sender",
            email="sender@gmail.com",
            full_name="Pengirim",
            phone="081111111111",
            password="secret123",
            pin="123456",
            balance=100000,
        )
        self.receiver = AuthService.create_user(
            username="receiver",
            email="receiver@gmail.com",
            full_name="Penerima",
            phone="082222222222",
            password="secret123",
            pin="123456",
            balance=25000,
        )

    def test_transfer_updates_balances_transactions_and_notifications(self):
        TransferService(self.sender).transfer("receiver", 20000, "123456")
        self.sender.refresh_from_db()
        self.receiver.refresh_from_db()

        self.assertEqual(self.sender.balance, 80000)
        self.assertEqual(self.receiver.balance, 45000)
        self.assertEqual(Transaction.objects.count(), 2)
        self.assertEqual(Notification.objects.count(), 2)

    def test_transfer_rejects_wrong_pin(self):
        with self.assertRaisesMessage(ValueError, "PIN transaksi salah."):
            TransferService(self.sender).transfer("receiver", 20000, "999999")

    def test_blocked_user_cannot_transfer(self):
        self.sender.status = User.STATUS_BLOCKED
        self.sender.save(update_fields=["status"])

        with self.assertRaisesMessage(ValueError, "Akun Anda sedang diblokir."):
            TransferService(self.sender).transfer("receiver", 20000, "123456")

    def test_topup_approval_updates_balance_and_transaction(self):
        topup = TopUpService.create_topup(self.sender, 50000, TopUp.PAYMENT_BANK)
        TopUpService.approve_topup(topup)
        self.sender.refresh_from_db()
        topup.refresh_from_db()

        self.assertEqual(self.sender.balance, 150000)
        self.assertEqual(topup.status, TopUp.STATUS_SUCCESS)
        self.assertTrue(Transaction.objects.filter(transaction_type=Transaction.TYPE_TOPUP).exists())

    def test_transfer_view_requires_confirmation_before_processing(self):
        self.client.login(username="sender", password="secret123")

        response = self.client.post(
            reverse("transfer"),
            {"receiver": "receiver", "amount": "20000", "pin": "123456"},
        )
        self.sender.refresh_from_db()
        self.receiver.refresh_from_db()

        self.assertRedirects(response, reverse("transfer_confirm"))
        self.assertEqual(self.sender.balance, 100000)
        self.assertEqual(self.receiver.balance, 25000)

        confirm_response = self.client.post(reverse("transfer_confirm"))
        self.sender.refresh_from_db()
        self.receiver.refresh_from_db()

        self.assertRedirects(confirm_response, reverse("history"))
        self.assertEqual(self.sender.balance, 80000)
        self.assertEqual(self.receiver.balance, 45000)

# Create your tests here.
