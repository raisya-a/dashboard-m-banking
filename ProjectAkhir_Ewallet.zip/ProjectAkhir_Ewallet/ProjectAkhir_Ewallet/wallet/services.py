import random
from decimal import Decimal

from django.contrib.auth.hashers import check_password
from django.db import transaction
from django.db.models import Q
from django.utils import timezone

from accounts.models import User
from notifications.services import NotificationService

from .models import TopUp, Transaction
from .transaction_types import TopUpTransaction, TransferInTransaction, TransferOutTransaction


class WalletService:
    def __init__(self, user):
        self.__user = user

    def get_balance(self):
        return self.__user.balance

    def increase_balance(self, amount):
        self.__user.balance += Decimal(amount)
        self.__user.save(update_fields=["balance"])

    def decrease_balance(self, amount):
        amount = Decimal(amount)
        if self.__user.balance < amount:
            raise ValueError("Saldo tidak mencukupi.")
        self.__user.balance -= amount
        self.__user.save(update_fields=["balance"])


class TransferService:
    def __init__(self, sender):
        self.sender = sender

    def find_receiver(self, receiver):
        try:
            return User.objects.get(Q(email=receiver) | Q(username=receiver), role=User.ROLE_USER)
        except User.DoesNotExist as exc:
            raise ValueError("Penerima tidak ditemukan.") from exc

    def validate(self, receiver, amount, pin):
        if self.sender.is_blocked():
            raise ValueError("Akun Anda sedang diblokir.")
        if receiver == self.sender:
            raise ValueError("Tidak bisa transfer ke akun sendiri.")
        if Decimal(amount) <= 0:
            raise ValueError("Nominal transfer harus lebih dari 0.")
        if self.sender.balance < Decimal(amount):
            raise ValueError("Saldo tidak mencukupi.")
        if not check_password(pin, self.sender.pin):
            raise ValueError("PIN transaksi salah.")

    def transfer(self, receiver_value, amount, pin):
        amount = Decimal(amount)
        with transaction.atomic():
            sender = User.objects.select_for_update().get(pk=self.sender.pk)
            self.sender = sender
            receiver = self.find_receiver(receiver_value)
            receiver = User.objects.select_for_update().get(pk=receiver.pk)
            self.validate(receiver, amount, pin)

            WalletService(sender).decrease_balance(amount)
            WalletService(receiver).increase_balance(amount)

            out_trx = TransferOutTransaction(sender, amount, receiver).process()
            in_trx = TransferInTransaction(receiver, amount, sender).process()

            NotificationService.create_notification(
                sender,
                "Transfer Berhasil",
                f"Transfer sebesar Rp {amount:,.2f} ke {receiver.full_name} berhasil.",
            )
            NotificationService.create_notification(
                receiver,
                "Saldo Masuk",
                f"Anda menerima transfer sebesar Rp {amount:,.2f} dari {sender.full_name}.",
            )
            return out_trx, in_trx


class TopUpService:
    @staticmethod
    def generate_code(prefix):
        timestamp = timezone.now().strftime("%Y%m%d%H%M%S%f")
        return f"{prefix}-{timestamp}{random.randint(100, 999)}"

    @staticmethod
    def generate_payment_number():
        return "8808" + "".join(str(random.randint(0, 9)) for _ in range(10))

    @classmethod
    def create_topup(cls, user, amount, payment_method):
        if user.is_blocked():
            raise ValueError("Akun Anda sedang diblokir.")
        topup = TopUp.objects.create(
            user=user,
            topup_code=cls.generate_code("TOPUP"),
            payment_method=payment_method,
            amount=amount,
            payment_number=cls.generate_payment_number(),
        )
        NotificationService.create_notification(
            user,
            "Top Up Diajukan",
            f"Pengajuan top up Rp {Decimal(amount):,.2f} berhasil dibuat dan menunggu persetujuan admin.",
        )
        return topup

    @staticmethod
    def approve_topup(topup):
        with transaction.atomic():
            topup = TopUp.objects.select_for_update().get(pk=topup.pk)
            if topup.status != TopUp.STATUS_PENDING:
                raise ValueError("Top up ini sudah diproses.")
            user = User.objects.select_for_update().get(pk=topup.user.pk)
            topup.user = user

            WalletService(user).increase_balance(topup.amount)
            topup.status = TopUp.STATUS_SUCCESS
            topup.approved_at = timezone.now()
            topup.save(update_fields=["status", "approved_at"])
            TopUpTransaction(user, topup.amount, description=f"Top up {topup.topup_code} disetujui.").process()
            NotificationService.create_notification(
                user,
                "Top Up Berhasil",
                f"Top up sebesar Rp {topup.amount:,.2f} telah disetujui admin.",
            )
            return topup

    @staticmethod
    def reject_topup(topup):
        topup.status = TopUp.STATUS_FAILED
        topup.save(update_fields=["status"])
        NotificationService.create_notification(
            topup.user,
            "Top Up Ditolak",
            f"Pengajuan top up {topup.topup_code} ditolak admin.",
        )
        Transaction.objects.create(
            transaction_code=TopUpService.generate_code("TRX"),
            user=topup.user,
            transaction_type=Transaction.TYPE_TOPUP,
            amount=topup.amount,
            balance_before=topup.user.balance,
            balance_after=topup.user.balance,
            status=Transaction.STATUS_FAILED,
            description=f"Top up {topup.topup_code} ditolak.",
        )
        return topup
