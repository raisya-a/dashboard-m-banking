from abc import ABC, abstractmethod
import random

from django.utils import timezone


class TransactionInterface(ABC):
    @abstractmethod
    def process(self):
        pass


class BaseTransaction(TransactionInterface):
    prefix = "TRX"

    def __init__(self, user, amount, target_user=None, description=""):
        self.user = user
        self.amount = amount
        self.target_user = target_user
        self.description = description

    def generate_code(self):
        timestamp = timezone.now().strftime("%Y%m%d%H%M%S%f")
        random_number = random.randint(100, 999)
        return f"{self.prefix}-{timestamp}{random_number}"
