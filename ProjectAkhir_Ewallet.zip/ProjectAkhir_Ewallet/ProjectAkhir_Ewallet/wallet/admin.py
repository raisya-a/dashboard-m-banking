from django.contrib import admin

from .models import TopUp, Transaction


@admin.register(Transaction)
class TransactionAdmin(admin.ModelAdmin):
    list_display = ("transaction_code", "user", "transaction_type", "amount", "status", "created_at")
    list_filter = ("transaction_type", "status")
    search_fields = ("transaction_code", "user__username", "user__full_name")


@admin.register(TopUp)
class TopUpAdmin(admin.ModelAdmin):
    list_display = ("topup_code", "user", "amount", "payment_method", "status", "created_at")
    list_filter = ("payment_method", "status")
    search_fields = ("topup_code", "user__username", "user__full_name")

# Register your models here.
