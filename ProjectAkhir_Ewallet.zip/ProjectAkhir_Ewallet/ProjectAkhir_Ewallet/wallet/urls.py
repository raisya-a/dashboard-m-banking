from django.urls import path

from . import views

urlpatterns = [
    path("dashboard/", views.user_dashboard, name="user_dashboard"),
    path("wallet/", views.wallet_view, name="wallet"),
    path("transfer/", views.transfer_view, name="transfer"),
    path("transfer/confirm/", views.transfer_confirm_view, name="transfer_confirm"),
    path("transfer/cancel/", views.transfer_cancel_view, name="transfer_cancel"),
    path("topup/", views.topup_view, name="topup"),
    path("history/", views.history_view, name="history"),
]
