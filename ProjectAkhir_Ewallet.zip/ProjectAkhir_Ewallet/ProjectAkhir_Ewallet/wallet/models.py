from django.conf import settings
from django.db import models


class Transaction(models.Model):
    TYPE_TOPUP = "topup"
    TYPE_TRANSFER_IN = "transfer_in"
    TYPE_TRANSFER_OUT = "transfer_out"
    STATUS_PENDING = "pending"
    STATUS_SUCCESS = "success"
    STATUS_FAILED = "failed"

    TYPE_CHOICES = (
        (TYPE_TOPUP, "Top Up"),
        (TYPE_TRANSFER_IN, "Transfer Masuk"),
        (TYPE_TRANSFER_OUT, "Transfer Keluar"),
    )
    STATUS_CHOICES = (
        (STATUS_PENDING, "Pending"),
        (STATUS_SUCCESS, "Berhasil"),
        (STATUS_FAILED, "Gagal"),
    )

    transaction_code = models.CharField(max_length=50, unique=True)
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="transactions")
    target_user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="target_transactions",
    )
    transaction_type = models.CharField(max_length=30, choices=TYPE_CHOICES)
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    balance_before = models.DecimalField(max_digits=12, decimal_places=2)
    balance_after = models.DecimalField(max_digits=12, decimal_places=2)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=STATUS_SUCCESS)
    description = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return self.transaction_code


class TopUp(models.Model):
    PAYMENT_BANK = "transfer_bank"
    PAYMENT_VA = "virtual_account"
    STATUS_PENDING = "pending"
    STATUS_SUCCESS = "success"
    STATUS_FAILED = "failed"

    PAYMENT_CHOICES = (
        (PAYMENT_BANK, "Transfer Bank"),
        (PAYMENT_VA, "Virtual Account"),
    )
    STATUS_CHOICES = (
        (STATUS_PENDING, "Pending"),
        (STATUS_SUCCESS, "Berhasil"),
        (STATUS_FAILED, "Gagal"),
    )

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="topups")
    topup_code = models.CharField(max_length=50, unique=True)
    payment_method = models.CharField(max_length=30, choices=PAYMENT_CHOICES)
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=STATUS_PENDING)
    payment_number = models.CharField(max_length=100, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    approved_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return self.topup_code

# Create your models here.
