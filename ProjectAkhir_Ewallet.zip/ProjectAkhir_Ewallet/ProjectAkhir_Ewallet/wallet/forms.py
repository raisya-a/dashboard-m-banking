from django import forms


class TransferForm(forms.Form):
    receiver = forms.CharField(label="Email atau Username Penerima")
    amount = forms.DecimalField(label="Nominal Transfer", min_value=1000)
    pin = forms.CharField(label="PIN Transaksi", min_length=6, max_length=6, widget=forms.PasswordInput)


class TopUpForm(forms.Form):
    PAYMENT_CHOICES = (
        ("transfer_bank", "Transfer Bank"),
        ("virtual_account", "Virtual Account"),
    )

    amount = forms.DecimalField(label="Nominal Top Up", min_value=10000)
    payment_method = forms.ChoiceField(label="Metode Pembayaran", choices=PAYMENT_CHOICES)
