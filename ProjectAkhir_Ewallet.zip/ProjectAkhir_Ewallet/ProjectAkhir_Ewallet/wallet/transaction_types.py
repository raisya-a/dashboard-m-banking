from .abstractions import BaseTransaction
from .models import Transaction


class TopUpTransaction(BaseTransaction):
    def process(self):
        return Transaction.objects.create(
            transaction_code=self.generate_code(),
            user=self.user,
            transaction_type=Transaction.TYPE_TOPUP,
            amount=self.amount,
            balance_before=self.user.balance - self.amount,
            balance_after=self.user.balance,
            status=Transaction.STATUS_SUCCESS,
            description=self.description or "Top up saldo berhasil.",
        )


class TransferOutTransaction(BaseTransaction):
    def process(self):
        return Transaction.objects.create(
            transaction_code=self.generate_code(),
            user=self.user,
            target_user=self.target_user,
            transaction_type=Transaction.TYPE_TRANSFER_OUT,
            amount=self.amount,
            balance_before=self.user.balance + self.amount,
            balance_after=self.user.balance,
            status=Transaction.STATUS_SUCCESS,
            description=self.description or f"Transfer ke {self.target_user.full_name}.",
        )


class TransferInTransaction(BaseTransaction):
    def process(self):
        return Transaction.objects.create(
            transaction_code=self.generate_code(),
            user=self.user,
            target_user=self.target_user,
            transaction_type=Transaction.TYPE_TRANSFER_IN,
            amount=self.amount,
            balance_before=self.user.balance - self.amount,
            balance_after=self.user.balance,
            status=Transaction.STATUS_SUCCESS,
            description=self.description or f"Transfer dari {self.target_user.full_name}.",
        )
