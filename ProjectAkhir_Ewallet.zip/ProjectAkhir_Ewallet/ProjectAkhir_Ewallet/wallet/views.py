from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db.models import Sum
from django.shortcuts import redirect, render

from accounts.decorators import user_required

from .forms import TopUpForm, TransferForm
from .models import TopUp, Transaction
from .services import TopUpService, TransferService
from dashboard.utils import paginate_queryset, pagination_querystring


@login_required
@user_required
def user_dashboard(request):
    user = request.user
    transfer_in = Transaction.objects.filter(user=user, transaction_type=Transaction.TYPE_TRANSFER_IN).aggregate(
        total=Sum("amount")
    )["total"] or 0
    transfer_out = Transaction.objects.filter(user=user, transaction_type=Transaction.TYPE_TRANSFER_OUT).aggregate(
        total=Sum("amount")
    )["total"] or 0
    topup_total = Transaction.objects.filter(
        user=user,
        transaction_type=Transaction.TYPE_TOPUP,
        status=Transaction.STATUS_SUCCESS,
    ).aggregate(total=Sum("amount"))["total"] or 0
    notifications = user.notifications.all()[:5]
    recent_transactions = Transaction.objects.filter(
        user=user,
        transaction_type__in=[Transaction.TYPE_TRANSFER_IN, Transaction.TYPE_TRANSFER_OUT],
    )[:3]
    return render(
        request,
        "user/dashboard.html",
        {
            "transfer_in": transfer_in,
            "transfer_out": transfer_out,
            "topup_total": topup_total,
            "notifications": notifications,
            "recent_transactions": recent_transactions,
        },
    )


@login_required
@user_required
def wallet_view(request):
    return render(request, "user/wallet.html")


@login_required
@user_required
def transfer_view(request):
    form = TransferForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        try:
            service = TransferService(request.user)
            receiver = service.find_receiver(form.cleaned_data["receiver"])
            service.validate(receiver, form.cleaned_data["amount"], form.cleaned_data["pin"])
            request.session["pending_transfer"] = {
                "receiver": form.cleaned_data["receiver"],
                "receiver_name": receiver.full_name,
                "receiver_email": receiver.email,
                "amount": str(form.cleaned_data["amount"]),
                "pin": form.cleaned_data["pin"],
            }
            return redirect("transfer_confirm")
        except Exception as exc:
            messages.error(request, str(exc))
    return render(request, "user/transfer.html", {"form": form})


@login_required
@user_required
def transfer_confirm_view(request):
    pending_transfer = request.session.get("pending_transfer")
    if not pending_transfer:
        messages.error(request, "Tidak ada transfer yang perlu dikonfirmasi.")
        return redirect("transfer")

    if request.method == "POST":
        try:
            TransferService(request.user).transfer(
                pending_transfer["receiver"],
                pending_transfer["amount"],
                pending_transfer["pin"],
            )
            request.session.pop("pending_transfer", None)
            messages.success(request, "Transfer saldo berhasil.")
            return redirect("history")
        except Exception as exc:
            request.session.pop("pending_transfer", None)
            messages.error(request, str(exc))
            return redirect("transfer")

    return render(request, "user/transfer_confirm.html", {"transfer": pending_transfer})


@login_required
@user_required
def transfer_cancel_view(request):
    request.session.pop("pending_transfer", None)
    messages.success(request, "Transfer dibatalkan.")
    return redirect("transfer")


@login_required
@user_required
def topup_view(request):
    form = TopUpForm(request.POST or None)
    topup = None
    if request.method == "POST" and form.is_valid():
        try:
            topup = TopUpService.create_topup(
                request.user,
                form.cleaned_data["amount"],
                form.cleaned_data["payment_method"],
            )
            messages.success(request, "Pengajuan top up berhasil dibuat.")
            form = TopUpForm()
        except Exception as exc:
            messages.error(request, str(exc))
    topups = TopUp.objects.filter(user=request.user)
    page_obj = paginate_queryset(request, topups, 5)
    return render(
        request,
        "user/topup.html",
        {
            "form": form,
            "topup": topup,
            "recent_topups": page_obj,
            "page_obj": page_obj,
            "pagination_query": pagination_querystring(request),
        },
    )


@login_required
@user_required
def history_view(request):
    transactions = Transaction.objects.filter(
        user=request.user,
        transaction_type__in=[Transaction.TYPE_TRANSFER_IN, Transaction.TYPE_TRANSFER_OUT],
    )
    page_obj = paginate_queryset(request, transactions, 10)
    return render(
        request,
        "user/history.html",
        {"transactions": page_obj, "page_obj": page_obj, "pagination_query": pagination_querystring(request)},
    )

# Create your views here.
