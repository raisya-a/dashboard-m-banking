from django.contrib import admin

from .models import Report, ReportMessage


class ReportMessageInline(admin.TabularInline):
    model = ReportMessage
    extra = 0


@admin.register(Report)
class ReportAdmin(admin.ModelAdmin):
    list_display = ("subject", "user", "category", "status", "created_at")
    list_filter = ("category", "status")
    search_fields = ("subject", "user__username", "user__full_name")
    inlines = [ReportMessageInline]

# Register your models here.
