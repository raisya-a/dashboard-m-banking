from django import forms

from .models import Report


class ReportForm(forms.Form):
    subject = forms.CharField(label="Judul Report", max_length=150)
    category = forms.ChoiceField(label="Kategori", choices=Report.CATEGORY_CHOICES)
    message = forms.CharField(label="Pesan", widget=forms.Textarea)


class ReportReplyForm(forms.Form):
    message = forms.CharField(label="Balasan", widget=forms.Textarea)
