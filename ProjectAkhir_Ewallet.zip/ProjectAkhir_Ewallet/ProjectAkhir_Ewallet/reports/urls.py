from django.urls import path

from . import views

urlpatterns = [
    path("", views.report_list, name="report_list"),
    path("create/", views.report_create, name="report_create"),
    path("<int:report_id>/", views.report_detail, name="report_detail"),
    path("admin/", views.admin_report_list, name="admin_report_list"),
    path("admin/<int:report_id>/", views.admin_report_detail, name="admin_report_detail"),
    path("admin/<int:report_id>/close/", views.admin_report_close, name="admin_report_close"),
]
