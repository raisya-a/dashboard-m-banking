from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404, redirect, render

from accounts.decorators import admin_required, user_required

from .forms import ReportForm, ReportReplyForm
from .models import Report
from .services import ReportService
from dashboard.utils import paginate_queryset, pagination_querystring


@login_required
@user_required
def report_list(request):
    reports = Report.objects.filter(user=request.user)
    page_obj = paginate_queryset(request, reports, 10)
    return render(
        request,
        "user/reports/index.html",
        {"reports": page_obj, "page_obj": page_obj, "pagination_query": pagination_querystring(request)},
    )


@login_required
@user_required
def report_create(request):
    form = ReportForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        ReportService.create_report(
            request.user,
            form.cleaned_data["subject"],
            form.cleaned_data["category"],
            form.cleaned_data["message"],
        )
        messages.success(request, "Report berhasil dikirim ke admin.")
        return redirect("report_list")
    return render(request, "user/reports/create.html", {"form": form})


@login_required
@user_required
def report_detail(request, report_id):
    report = get_object_or_404(Report, pk=report_id, user=request.user)
    form = ReportReplyForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        try:
            ReportService.send_message(report, request.user, form.cleaned_data["message"])
            messages.success(request, "Pesan berhasil dikirim.")
            return redirect("report_detail", report_id=report.id)
        except ValueError as exc:
            messages.error(request, str(exc))
    return render(request, "user/reports/detail.html", {"report": report, "form": form})


@login_required
@admin_required
def admin_report_list(request):
    reports = Report.objects.select_related("user").all()
    page_obj = paginate_queryset(request, reports, 10)
    return render(
        request,
        "admin_panel/reports/index.html",
        {"reports": page_obj, "page_obj": page_obj, "pagination_query": pagination_querystring(request)},
    )


@login_required
@admin_required
def admin_report_detail(request, report_id):
    report = get_object_or_404(Report.objects.select_related("user"), pk=report_id)
    form = ReportReplyForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        try:
            ReportService.send_message(report, request.user, form.cleaned_data["message"])
            messages.success(request, "Balasan berhasil dikirim.")
            return redirect("admin_report_detail", report_id=report.id)
        except ValueError as exc:
            messages.error(request, str(exc))
    return render(request, "admin_panel/reports/detail.html", {"report": report, "form": form})


@login_required
@admin_required
def admin_report_close(request, report_id):
    report = get_object_or_404(Report, pk=report_id)
    ReportService.close_report(report)
    messages.success(request, "Report berhasil ditutup.")
    return redirect("admin_report_detail", report_id=report.id)

# Create your views here.
