from notifications.services import NotificationService

from .models import Report, ReportMessage


class ReportService:
    @staticmethod
    def create_report(user, subject, category, message):
        report = Report.objects.create(user=user, subject=subject, category=category)
        ReportMessage.objects.create(report=report, sender=user, message=message)
        return report

    @staticmethod
    def send_message(report, sender, message):
        if report.status == Report.STATUS_CLOSED:
            raise ValueError("Report sudah ditutup.")
        if report.status == Report.STATUS_OPEN:
            report.status = Report.STATUS_PROCESS
            report.save(update_fields=["status"])
        report_message = ReportMessage.objects.create(report=report, sender=sender, message=message)

        if sender.role == "admin":
            NotificationService.create_notification(
                report.user,
                "Report Dibalas Admin",
                f"Admin membalas report: {report.subject}.",
            )
        return report_message

    @staticmethod
    def close_report(report):
        report.close_report()
        NotificationService.create_notification(
            report.user,
            "Report Ditutup",
            f"Report Anda dengan judul {report.subject} telah ditutup.",
        )
        return report
