from django.test import TestCase

from accounts.models import User
from accounts.services import AuthService
from notifications.models import Notification
from reports.models import Report
from reports.services import ReportService


class ReportServiceTests(TestCase):
    def setUp(self):
        self.user = AuthService.create_user(
            username="user",
            email="user@gmail.com",
            full_name="User Demo",
            phone="081234567890",
            password="user123",
            pin="123456",
        )
        self.admin = AuthService.create_user(
            username="admin",
            email="admin@gmail.com",
            full_name="Administrator",
            phone="080000000000",
            password="admin123",
            pin="123456",
            role=User.ROLE_ADMIN,
        )

    def test_admin_reply_creates_notification(self):
        report = ReportService.create_report(self.user, "Minta buka blokir", Report.CATEGORY_UNBLOCK, "Mohon dibuka.")
        ReportService.send_message(report, self.admin, "Akan kami cek.")

        self.assertEqual(report.messages.count(), 2)
        self.assertTrue(Notification.objects.filter(user=self.user, title="Report Dibalas Admin").exists())

# Create your tests here.
