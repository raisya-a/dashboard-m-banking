from django.conf import settings
from django.db import models


class Report(models.Model):
    CATEGORY_GENERAL = "general"
    CATEGORY_UNBLOCK = "unblock_request"
    CATEGORY_TRANSACTION = "transaction_problem"
    STATUS_OPEN = "open"
    STATUS_PROCESS = "process"
    STATUS_CLOSED = "closed"

    CATEGORY_CHOICES = (
        (CATEGORY_GENERAL, "Umum"),
        (CATEGORY_UNBLOCK, "Pengajuan Buka Blokir"),
        (CATEGORY_TRANSACTION, "Masalah Transaksi"),
    )
    STATUS_CHOICES = (
        (STATUS_OPEN, "Terbuka"),
        (STATUS_PROCESS, "Diproses"),
        (STATUS_CLOSED, "Ditutup"),
    )

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="reports")
    subject = models.CharField(max_length=150)
    category = models.CharField(max_length=30, choices=CATEGORY_CHOICES)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=STATUS_OPEN)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def close_report(self):
        self.status = self.STATUS_CLOSED
        self.save(update_fields=["status"])

    def __str__(self):
        return self.subject


class ReportMessage(models.Model):
    report = models.ForeignKey(Report, on_delete=models.CASCADE, related_name="messages")
    sender = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["created_at"]

    def __str__(self):
        return f"Pesan dari {self.sender.full_name}"

# Create your models here.
