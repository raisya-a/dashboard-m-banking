from .models import Report


def admin_report_notifications(request):
    if not request.user.is_authenticated or getattr(request.user, "role", None) != "admin":
        return {}

    count = Report.objects.filter(status__in=[Report.STATUS_OPEN, Report.STATUS_PROCESS]).count()
    return {"admin_open_report_count": count}
